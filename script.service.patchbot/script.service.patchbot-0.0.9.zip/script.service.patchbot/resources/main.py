if 64 - 64:
    i11iIiiIii
if 65 - 65:
    O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import xbmc, xbmcaddon, xbmcgui, os, urllib2, urllib, json, cookielib, time, zipfile, shutil, hashlib, base64
if 73 - 73:
    II111iiii
if 22 - 22:
    I1IiiI * Oo0Ooo / OoO0O00.OoOoOO00.o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48:
    oO0o / OOooOOo / I11i / Ii1I
IiiIII111iI = '4aa8b4054ddd222cd60788c68a72a731'
IiII = 'script.service.patchbot'
iI1Ii11111iIi = xbmcaddon.Addon(IiII)
i1i1II = iI1Ii11111iIi.getAddonInfo('id')
O0oo0OO0 = iI1Ii11111iIi.getAddonInfo('name')
I1i1iiI1 = iI1Ii11111iIi.getAddonInfo('icon')
iiIIIII1i1iI = iI1Ii11111iIi.getAddonInfo('version')
o0oO0 = xbmc.translatePath('special://profile/addon_data/%s/' % IiII)
oo00 = iI1Ii11111iIi.getAddonInfo('path')
o00 = xbmc.translatePath(os.path.join('special://home/addons', 'packages'))
Oo0oO0ooo = xbmc.translatePath(os.path.join('special://home', ''))
o0oOoO00o = xbmc.translatePath(os.path.expanduser('~/'))
i1 = xbmc.translatePath(o0oO0 + 'settings.xml')
oOOoo00O0O = xbmc.translatePath(oo00 + '/settings-default.xml')
if 15 - 15:
    I11iii11IIi
O00o0o0000o0o = base64.b64decode('aHR0cDovL3VwZGF0ZS5tZWRpYXBsYXllcng5LmNvbS9wYXRjaGJvdC9zeW5jLnBocA==')
O0Oo = base64.b64decode('')
oo = base64.b64decode('')
if 33 - 33:
    I1I1i1 * oO0 / OOo0o0 / I11i - OOooOOo % Oo0Ooo
if 7 - 7:
    I1IiiI / I11i * I1IiiI / OoO0O00
if 41 - 41:
    OoO0O00.oO0

class OoOooOOOO():

    def setAlarm(self, mins=0, args=0):
        if 0:
            oO0 + Ii1I
        if mins == 0:
            mins = int(self.getSetting('check_frequency'))
        if args == 0:
            args = ''
        iII111ii = O0oo0OO0 + ' - Patch Update scheduler'
        i1iIIi1 = os.path.join(oo00, 'default.py')
        ii11iIi1I = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (iII111ii, i1iIIi1, args, mins)
        if 0:
            OoOoOO00 * I11iii11IIi
        xbmc.executebuiltin('CancelAlarm(%s,True)' % iII111ii)
        xbmc.executebuiltin(ii11iIi1I)
        xbmc.log('Alarm Set: %s' % iII111ii)
        if 0:
            OOo0o0 - oO0o * o0oOOo0O0Ooo % o0oOOo0O0Ooo % I11i * OoOoOO00
        if 0:
            Ii1I - o0oOOo0O0Ooo

    def getSetting(self, setting):
        return xbmcaddon.Addon(id=IiII).getSetting(setting)
        if 0:
            II111iiii.II111iiii
        if 0:
            i1IIi.I11i % OoO0O00.o0oOOo0O0Ooo

    def setSetting(self, setting, value):
        xbmcaddon.Addon(id=IiII).setSetting(setting, value)
        if 0:
            oO0 + I1ii11iIi11i
        if 0:
            Oo0Ooo % Oo0Ooo.I1I1i1 % OoO0O00 * o0oOOo0O0Ooo % oO0o

    def setDefaults(self):
        if 0:
            i11iIiiIii + I1IiiI
        if not os.path.exists(o0oO0):
            os.mkdir(o0oO0)
            if 0:
                OoOoOO00.oO0o.i11iIiiIii
        if not os.path.exists(i1):
            shutil.copy(oOOoo00O0O, i1)
            if 0:
                oO0o.OoOoOO00.Oo0Ooo.i1IIi
            if 0:
                Ii1I + II111iiii % i11iIiiIii.OOo0o0 - I1IiiI

    def check_server(self):
        O00oooo0O = O00o0o0000o0o
        IiI1i11iii1 = O0Oo
        oo0Oo00Oo0 = oo
        oOOO00o = self.getSetting('build_id')
        try:
            O0O00o0OOO0 = cookielib.CookieJar()
            Ii1iIIIi1ii = urllib2.build_opener(urllib2.HTTPCookieProcessor(O0O00o0OOO0))
            o0oo0o0O00OO = urllib.urlencode({'username': IiI1i11iii1, 'password': oo0Oo00Oo0})
            Ii1iIIIi1ii.open(O00oooo0O, o0oo0o0O00OO)
            o0oO = urllib.urlencode({'build_id': oOOO00o})
            I1i1iii = Ii1iIIIi1ii.open(O00oooo0O, o0oO)
            i1iiI11I = I1i1iii.read()
            i1iiI11I = json.loads(u'' + i1iiI11I)
        except:
            i1iiI11I = False

        return i1iiI11I
        if 0:
            OoooooooOO
        if 0:
            o0oOOo0O0Ooo.II111iiii

    def log_download_on_server(self):
        if 0:
            iIii1I11I1II1 % OoOoOO00 * I1ii11iIi11i * OoOoOO00
        O00oooo0O = O00o0o0000o0o
        IiI1i11iii1 = O0Oo
        oo0Oo00Oo0 = oo
        oOOO00o = self.getSetting('build_id')
        try:
            O0O00o0OOO0 = cookielib.CookieJar()
            Ii1iIIIi1ii = urllib2.build_opener(urllib2.HTTPCookieProcessor(O0O00o0OOO0))
            o0oo0o0O00OO = urllib.urlencode({'username': IiI1i11iii1, 'password': oo0Oo00Oo0})
            Ii1iIIIi1ii.open(O00oooo0O, o0oo0o0O00OO)
            o0oO = urllib.urlencode({'download_request': oOOO00o})
            I1i1iii = Ii1iIIIi1ii.open(O00oooo0O, o0oO)
            i1iiI11I = I1i1iii.read()
            i1iiI11I = json.loads(u'' + i1iiI11I)
        except:
            i1iiI11I = False

        return i1iiI11I
        if 0:
            oO0.OoOoOO00
        if 0:
            oO0o.iIii1I11I1II1.I1ii11iIi11i

    def getDownloadPath(self):
        return os.path.join(o00, self.getSetting('build_id') + '.zip')
        if 0:
            Ii1I.Ii1I - o0oOOo0O0Ooo / OoO0O00 + OOo0o0 * I1IiiI
        if 0:
            oO0 % i1IIi / OoooooooOO - OoooooooOO

    def compareDates(self, new, old):
        if 0:
            OoOoOO00
        from datetime import datetime

        try:
            o00O = datetime.fromtimestamp(time.mktime(time.strptime(new, '%Y%m%d%H%M')))
            OOO0OOO00oo = datetime.fromtimestamp(time.mktime(time.strptime(old, '%Y%m%d%H%M')))
        except:
            xbmc.log('huang log new: ' + str(new), level=xbmc.LOGERROR)
            xbmc.log('huang log old: ' + str(old), level=xbmc.LOGERROR)
        if o00O > OOO0OOO00oo:
            return True
        return False
        if 0:
            II111iiii - OOooOOo.oO0 % OoOoOO00 - O0
        if 0:
            II111iiii / OOo0o0.I11iii11IIi

    def checkForUpdate(self):
        if self.getSetting('disabled').rstrip('\n').lower() == 'true':
            xbmc.log(O0oo0OO0 + ': Addon disabled. Exiting...', level=xbmc.LOGERROR)
            return
        print O0oo0OO0 + ' - Checking latest patch updates...'
        self.setDefaults()
        O0oo0OO0oOOOo = self.check_server()
        print O0oo0OO0oOOOo
        i1i1i11IIi = self.getSetting('date_created').rstrip('\n')
        II1III = {}
        II1III['build_id'] = self.getSetting('build_id').rstrip('\n')
        II1III['build_name'] = self.getSetting('build_name').rstrip('\n')
        II1III['date_created'] = i1i1i11IIi
        iI1iI1I1i1I = self.getDownloadPath()
        if not hashlib.md5(O00o0o0000o0o).hexdigest() == IiiIII111iI:
            iIi11Ii1 = False
            Ii11iII1 = False
            Oo0O0O0ooO0O = ['f', 'g', Ii11iII1]
            IIIIii = Oo0O0O0ooO0O
            O0o0 = [IIIIii, Ii11iII1, iIi11Ii1]
            O0oo0OO0oOOOo = [O0o0, Ii11iII1, Oo0O0O0ooO0O]
            i1iiI11I = False
        if 0:
            OOooOOo + OOo0o0 % i11iIiiIii + I1ii11iIi11i - I1I1i1
        try:
            if O0oo0OO0oOOOo:
                for oO0OOoO0 in O0oo0OO0oOOOo:
                    if oO0OOoO0['build_id'] in II1III['build_id']:
                        if self.compareDates(oO0OOoO0['date_created'], II1III['date_created']):
                            II1III['url'] = oO0OOoO0['url']
                            II1III['build_id'] = oO0OOoO0['build_id']
                            II1III['build_name'] = oO0OOoO0['build_name']
                            II1III['date_created'] = oO0OOoO0['date_created']
                            II1III['hash'] = oO0OOoO0['hash']
                            II1III['kodi_version'] = oO0OOoO0['kodi_version']
                            if 0:
                                I1I1i1 - I1I1i1 * I1IiiI + Ii1I % I1I1i1

        except Exception as i111IiI1I:
            xbmc.log(O0oo0OO0 + ': Exception occurred, checkForUpdate', level=xbmc.LOGERROR)
            xbmc.log(str(i111IiI1I), level=xbmc.LOGERROR)
            if 0:
                Ii1I.Oo0Ooo / o0oOOo0O0Ooo.Ii1I - O0 / I1I1i1

        if self.compareDates(II1III['date_created'], i1i1i11IIi):
            self.applyUpdate(II1III['url'], iI1iI1I1i1I, II1III['build_name'], II1III['date_created'], II1III['hash'], II1III['kodi_version'])
            if 0:
                iIii1I11I1II1 * OoOoOO00
        self.setAlarm()
        if 0:
            I11iii11IIi.oO0
        if 0:
            OoO0O00

    def check_kodi_version(self, req_kodi_version):
        if 0:
            OoO0O00 - I11iii11IIi / Oo0Ooo / OoOoOO00
        I1i1IiI1 = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.GetProperties", "params": {"properties": ["version", "name"]}, "id": 1 }')
        I1i1IiI1 = unicode(I1i1IiI1, 'utf-8', errors='ignore')
        I1i1IiI1 = json.loads(I1i1IiI1)
        oO0o0OOOO = []
        if I1i1IiI1.has_key('result') and I1i1IiI1['result'].has_key('version'):
            oO0o0OOOO = I1i1IiI1['result']['version']
        else:
            return False
        print oO0o0OOOO
        if 0:
            I11iii11IIi - oO0 - I1IiiI - I1ii11iIi11i + I11i
        iiiI1I11i1 = req_kodi_version.split('.')
        IIi1i11111 = str(oO0o0OOOO['major']).split('.')
        if int(iiiI1I11i1[0]) > int(IIi1i11111[0]):
            return str(oO0o0OOOO['major'])
        if len(iiiI1I11i1) == 1 and int(iiiI1I11i1[0]) == int(IIi1i11111[0]):
            return False
        return False
        if 0:
            i11iIiiIii % OoOoOO00 - OOooOOo
        if 0:
            oO0 % i1IIi.I1I1i1.I1ii11iIi11i

    def applyUpdate(self, url, path, name, date, md5sum, req_kodi_version):
        print (
         url, path, name, date, md5sum, req_kodi_version)
        if xbmc.getCondVisibility('Player.HasVideo'):
            time.sleep(30)
            if xbmc.getCondVisibility('Player.HasVideo'):
                self.setAlarm(30)
                return
                if 0:
                    I11iii11IIi.oO0
                if 0:
                    oO0.OoOoOO00 / O0
        o000O0o = name
        iI1iII1 = 'An update to this configuration is available.'
        oO0OOoo0OO = 'This update will be downloaded and applied in '
        O0ii1ii1ii = 'Click [B]Cancel[/B] to apply it later.'
        if not self.okUpdate(o000O0o, iI1iII1, oO0OOoo0OO, O0ii1ii1ii, delay=20):
            self.setAlarm(180)
            return
        oooooOoo0ooo = False
        I1I1IiI1 = xbmcgui.Dialog()
        III1iII1I1ii = xbmcgui.DialogProgress()
        if 0:
            II111iiii
        O0OOO = self.check_kodi_version(req_kodi_version)
        if O0OOO:
            I1I1IiI1.ok(o000O0o, 'This configuration requres that you update Kodi in order to continue...', 'You are running [B]Kodi ' + str(O0OOO) + '[/B]. A minimum of [B]Kodi' + str(req_kodi_version.split('.')[0]) + '[/B] is required.', '[COLOR red]Press Ok to Update Now[/COLOR]')
            if self.isember():
                i1iIIi1 = os.path.join(xbmcaddon.Addon(id='script.system.settings').getAddonInfo('path'), 'default.py')
                II11iIiIIIiI = 'mode=4'
                xbmc.executebuiltin('RunScript(%s,%s)' % (i1iIIi1, II11iIiIIIiI))
                oooooOoo0ooo = True
            else:
                I1I1IiI1.ok(o000O0o, 'Your system is not recognised.', 'You will need to update Kodi manually', '[COLOR red]Press Ok Cancel This Update[/COLOR]')
                oooooOoo0ooo = True
            if 0:
                oO0.I11iii11IIi.O0
        try:
            IIIIiiII111 = hashlib.md5(open(path, 'rb').read()).hexdigest()
        except:
            IIIIiiII111 = 'no file'

        if IIIIiiII111 == md5sum:
            xbmc.log(O0oo0OO0 + ': applyUpdate - md5checksum for downloaded file, %s, already matches that of remote download. Skipping download' % path, level=xbmc.LOGNOTICE)
        else:
            if not oooooOoo0ooo:
                xbmc.log(O0oo0OO0 + ': applyUpdate - Downloading file to %s' % path, level=xbmc.LOGNOTICE)
                III1iII1I1ii.create(o000O0o, 'Downloading & Copying File', '', 'In Progress...')
                try:
                    OOoOoo = self.downloader(url, path, III1iII1I1ii)
                    if not OOoOoo:
                        oooooOoo0ooo = True
                    self.log_download_on_server()
                    III1iII1I1ii.close()
                except Exception as i111IiI1I:
                    xbmc.log(O0oo0OO0 + ': Exception occurred, applyUpdate - calling downloader (possibly the download was canceled)', level=xbmc.LOGERROR)
                    xbmc.log(str(i111IiI1I), level=xbmc.LOGERROR)
                    oooooOoo0ooo = True
                    xbmc.executebuiltin('XBMC.Notification(%s, %s %s, 10000, %s)' % (O0oo0OO0, 'Failed to download update zip', '', I1i1iiI1))
                    III1iII1I1ii.close()
                    if 0:
                        I1ii11iIi11i % I11iii11IIi % OOo0o0

        if not oooooOoo0ooo:
            xbmc.log(O0oo0OO0 + ': applyUpdate - Extracting file %s' % path, level=xbmc.LOGNOTICE)
            III1iII1I1ii.create(o000O0o, 'Configuration Install', '', 'In Progress...')
            try:
                III1iII1I1ii.update(0, '', ' ', 'Extracting Files...')
                Oo00oo0oO = self.extract_zip(path, Oo0oO0ooo, III1iII1I1ii)
                if not Oo00oo0oO:
                    oooooOoo0ooo = True
                III1iII1I1ii.close()
            except Exception as i111IiI1I:
                oooooOoo0ooo = True
                xbmc.log(O0oo0OO0 + ': Exception occurred, applyUpdate - calling extract_zip (possibly the extract was canceled)', level=xbmc.LOGERROR)
                xbmc.log(str(i111IiI1I), level=xbmc.LOGERROR)
                xbmc.executebuiltin('XBMC.Notification(%s, %s %s, 10000, %s)' % (O0oo0OO0, 'Failed to extract update zip', '', I1i1iiI1))
                III1iII1I1ii.close()
                if 0:
                    OoO0O00 - oO0o.I11i.OoO0O00 / Oo0Ooo + I11i

        if not oooooOoo0ooo:
            self.setSetting('date_created', date)
            self.setSetting('build_name', name)
            xbmc.log(O0oo0OO0 + ': applyUpdate - Settings updated...Current version is now %s' % date, level=xbmc.LOGNOTICE)
            if 0:
                O0.oO0o.II111iiii % OOooOOo
            if self.isember():
                if os.path.isdir(os.path.join(Oo0oO0ooo, 'ROOT')):
                    III1iII1I1ii.create(o000O0o, 'Configuration Install', '', 'In Progress...')
                    III1iII1I1ii.update(0, '', ' ', 'Installing files to /root/...')
                    copy_dir(os.path.join(Oo0oO0ooo, 'ROOT'), o0oOoO00o, III1iII1I1ii)
                    shutil.rmtree(os.path.join(Oo0oO0ooo, 'ROOT'))
                    III1iII1I1ii.close()
                try:
                    self.show_busy('emberforcereboot')
                except:
                    xbmc.executebuiltin('UpdateLocalAddons')
                    xbmc.executebuiltin('UpdateAddonRepos')
                    I1I1IiI1.ok(o000O0o, 'Config Setup Complete', '', '[COLOR red]All Done Press Ok[/COLOR]')

            else:
                if os.path.isdir(os.path.join(Oo0oO0ooo, 'ROOT')):
                    shutil.rmtree(os.path.join(Oo0oO0ooo, 'ROOT'))
                try:
                    self.show_busy('emberforcereboot')
                except:
                    xbmc.executebuiltin('UpdateLocalAddons')
                    xbmc.executebuiltin('UpdateAddonRepos')
                    I1I1IiI1.ok(o000O0o, 'Config Setup Complete', '', '[COLOR red]All Done Press Ok[/COLOR]')

        self.setAlarm()
        if 0:
            Ii1I / OoO0O00.II111iiii
        if 0:
            i11iIiiIii % I1ii11iIi11i + i11iIiiIii

    def show_busy(self, cmd):
        if 0:
            II111iiii.I1IiiI
        II1I = O0i1II1Iiii1I11('busy.xml', iI1Ii11111iIi.getAddonInfo('path'), 'Default', cmd=cmd)
        II1I.doModal()
        if 0:
            I1ii11iIi11i / Oo0Ooo - I1IiiI / OoooooooOO / iIii1I11I1II1 - o0oOOo0O0Ooo
        if 0:
            I11iii11IIi % i1IIi % iIii1I11I1II1

    def okUpdate(self, title, line1, line2, line3='', delay=15):
        IIi1I11I1II = int(delay)
        if 0:
            OoooooooOO - OoO0O00.II111iiii / o0oOOo0O0Ooo.OoOoOO00 / O0
        III1iII1I1ii = xbmcgui.DialogProgress()
        III1iII1I1ii.create(title, line1, line2 + str(IIi1I11I1II) + 'seconds', line3)
        III1iII1I1ii.update(0)
        if 0:
            I1I1i1
        while IIi1I11I1II > 0 and not III1iII1I1ii.iscanceled():
            xbmc.sleep(1000)
            IIi1I11I1II -= 1
            OOO00O0O = int((delay - IIi1I11I1II) / float(delay) * 100)
            if 0:
                O0.I1I1i1.I1IiiI
            OoOO = str(line2 + '[B][COLOR red]' + str(IIi1I11I1II) + '[/COLOR]seconds[/B]')
            III1iII1I1ii.update(OOO00O0O, line1, OoOO, line3)
            if 0:
                Oo0Ooo

        return not III1iII1I1ii.iscanceled()
        if 0:
            I1ii11iIi11i + oO0o % O0
        if 0:
            I11i / oO0 - I1IiiI * iIii1I11I1II1 - I1IiiI

    def downloader(self, url, dest, dp=None):
        try:
            if 0:
                I1ii11iIi11i + I1IiiI * Ii1I + OOooOOo % I11iii11IIi
            import sys
            if sys.version_info < (2, 7, 9):
                raise Exception()
            import ssl
            OOOOOoo0 = ssl.create_default_context()
            OOOOOoo0.check_hostname = False
            OOOOOoo0.verify_mode = ssl.CERT_NONE
            ii1 = urllib2.urlopen(url, context=OOOOOoo0)
        except Exception as i111IiI1I:
            xbmc.log(O0oo0OO0 + ': downloader - Python version is < v2.7.9', level=xbmc.LOGNOTICE)
            xbmc.log(str(i111IiI1I), level=xbmc.LOGNOTICE)
            ii1 = urllib2.urlopen(url)

        if not dp:
            if 0:
                I1I1i1 * I1IiiI.iIii1I11I1II1 % OoooooooOO + I11iii11IIi
            OOO = open(dest, 'wb')
            oo0OOo0 = 0
            I11IiI = 8192
            while True:
                buffer = ii1.read(I11IiI)
                if not buffer:
                    break
                oo0OOo0 += len(buffer)
                OOO.write(buffer)

            OOO.close()
        else:
            if 0:
                I11iii11IIi % II111iiii.I1I1i1 - iIii1I11I1II1 - I1I1i1 * II111iiii
            dp.update(0)
            OOO = open(dest, 'wb')
            ooO0oOOooOo0 = ii1.info()
            i1I1ii11i1Iii = int(ooO0oOOooOo0.getheaders('Content-Length')[0])
            I1IiiiiI = int(time.time())
            oo0OOo0 = 0
            I11IiI = 8192
            time.sleep(1)
            while True:
                buffer = ii1.read(I11IiI)
                if not buffer:
                    break
                oo0OOo0 += int(len(buffer))
                if oo0OOo0 == 0:
                    oo0OOo0 = 1
                OOO.write(buffer)
                o0O = 100 * oo0OOo0 / i1I1ii11i1Iii
                IiIIii1iII1II = oo0OOo0 / 1048576
                Iii1I1I11iiI1 = float(i1I1ii11i1Iii) / 1048576
                I1I1i1I = int(time.time())
                ii1I = oo0OOo0 / (I1I1i1I - I1IiiiiI)
                if ii1I > 0:
                    O0oO0 = (i1I1ii11i1Iii - oo0OOo0) / ii1I
                else:
                    O0oO0 = 0
                oO0O0OO0O = ii1I / 1024
                OO = '%.02f MB of %.02f MB' % (IiIIii1iII1II, Iii1I1I11iiI1)
                i111IiI1I = 'Speed: %.02f Kb/s ' % oO0O0OO0O
                i111IiI1I += 'ETA: %02d:%02d' % divmod(O0oO0, 60)
                dp.update(o0O, '', OO, i111IiI1I)
                if dp.iscanceled():
                    raise Exception('Canceled')

            OOO.close()
        return True
        if 0:
            O0 / I1IiiI - OoO0O00 - OOooOOo
        if 0:
            I1I1i1

    def extract_zip(self, src, dest, dp=None):
        if 0:
            OOo0o0 / O0 * Oo0Ooo - OOooOOo % iIii1I11I1II1 * oO0o
        o0 = zipfile.ZipFile(src, 'r')
        iI11I1II = float(len(o0.infolist()))
        IIi1I11I1II = 0
        try:
            for Ii1IIiI1i in o0.infolist():
                IIi1I11I1II += 1
                o0Oo00 = IIi1I11I1II / iI11I1II * 100
                if dp:
                    dp.update(int(o0Oo00))
                o0.extract(Ii1IIiI1i, dest)
                if dp.iscanceled():
                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                    return False

        except Exception as i111IiI1I:
            if 0:
                o0oOOo0O0Ooo.I1I1i1 * I11i
            xbmc.log(O0oo0OO0 + ': Exception occurred, extract_zip', level=xbmc.LOGERROR)
            xbmc.log(str(i111IiI1I), level=xbmc.LOGERROR)
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            xbmc.executebuiltin('XBMC.Notification(%s, %s %s, 10000, %s)' % (O0oo0OO0, 'Failed to extract update zip', 'Please report this error', I1i1iiI1))
            return False

        return True
        if 0:
            o0oOOo0O0Ooo % i1IIi.Ii1I.i11iIiiIii
        if 0:
            I1ii11iIi11i % O0 - I1IiiI

    def copy_dir(self, source, destination, dp=None):
        try:
            xbmc.log(O0oo0OO0 + ': Folder Copy Started', level=xbmc.LOGNOTICE)
            O00o0OO0 = []
            if os.path.isdir(source):
                for iI1iI1I1i1I, IIi1I1iiiii, o00oOOooOOo0o in os.walk(source):
                    O00o0OO0.extend(o00oOOooOOo0o)

            O0O0ooOOO = len(O00o0OO0)
            if O0O0ooOOO > 0:
                if not os.path.exists(destination):
                    os.makedirs(destination)
                oOOo0O00o = 0
                I1IiiiiI = time.time()
                for iI1iI1I1i1I, IIi1I1iiiii, o00oOOooOOo0o in os.walk(source):
                    for iIiIi11 in IIi1I1iiiii:
                        OOOiiiiI = iI1iI1I1i1I.replace(source, destination)
                        if not os.path.exists(os.path.join(OOOiiiiI, iIiIi11)):
                            os.makedirs(os.path.join(OOOiiiiI, iIiIi11))

                    for oooOo0OOOoo0 in o00oOOooOOo0o:
                        OOoO = os.path.join(iI1iI1I1i1I, oooOo0OOOoo0)
                        OO0O000 = os.path.join(iI1iI1I1i1I.replace(source, destination), oooOo0OOOoo0)
                        try:
                            shutil.copy(OOoO, OO0O000)
                        except Exception as i111IiI1I:
                            xbmc.log(O0oo0OO0 + ': Exception occurred, copy_dir - Failed to move file', level=xbmc.LOGDEBUG)
                            xbmc.log(str(i111IiI1I), level=xbmc.LOGERROR)

                        oOOo0O00o += 1
                        iiIiI1i1 = int(round(oOOo0O00o / float(O0O0ooOOO) * 100))
                        ii1I = oOOo0O00o / (time.time() - I1IiiiiI)
                        if ii1I > 0:
                            O0oO0 = (float(O0O0ooOOO) - oOOo0O00o) / ii1I
                        else:
                            O0oO0 = 0
                        oO0O0OO0O = ii1I / 1024
                        if dp:
                            if 0:
                                OOo0o0
                            dp.update(iiIiI1i1)
                            if dp.iscanceled():
                                return False

            return destination
        except Exception as i111IiI1I:
            if 0:
                oO0 + OoooooooOO % o0oOOo0O0Ooo - iIii1I11I1II1.I1IiiI
            xbmc.log(O0oo0OO0 + ': Exception occurred, copy_dir', level=xbmc.LOGERROR)
            xbmc.log(str(i111IiI1I), level=xbmc.LOGERROR)
            return False
            if 0:
                o0oOOo0O0Ooo - oO0o / OoooooooOO
            if 0:
                I1IiiI / o0oOOo0O0Ooo % II111iiii % Oo0Ooo % OOooOOo

    def isember(self):
        if os.path.isfile('/etc/os-release'):
            O00oO000O0O = open('/etc/os-release')
            file = O00oO000O0O.readlines()
            I1i1i1iii = False
            for I1111i in file:
                if 'ID=' in I1111i and '_ID' not in I1111i:
                    I1i1i1iii = I1111i[I1111i.find('=') + 1:I1111i.find('\n')].rstrip('\n').lower()
                    if I1i1i1iii in ('ember', ):
                        return True

            if I1i1i1iii in ('ember', ):
                return True
            return False
            O00oO000O0O.close()
        else:
            return False
            if 0:
                OOooOOo / o0oOOo0O0Ooo
            if 0:
                I1IiiI * Oo0Ooo


class O0i1II1Iiii1I11(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.cmd = kwargs['cmd']
        if 0:
            OOooOOo - OoooooooOO - I1ii11iIi11i / OOo0o0 / II111iiii

    def onInit(self):
        self.line1 = self.getControl(9901)
        self.line2 = self.getControl(9902)
        self.line1.setLabel('')
        self.line2.setLabel('')
        if 0:
            I1IiiI % I1IiiI
        if 0:
            iIii1I11I1II1 / Oo0Ooo % I11iii11IIi * I11iii11IIi * II111iiii
        if self.cmd == 'restartkodi':
            self.line1.setLabel('Restarting Kodi,')
            self.line2.setLabel('please be patient.')
            time.sleep(2)
            try:
                xbmc.executebuiltin('RestartApp')
            except:
                IIiIiI = '/etc/init.d/S95kodi restart'
                subprocess.Popen(IIiIiI, shell=True, close_fds=True)
                if 0:
                    oO0o.i1IIi - o0oOOo0O0Ooo % O0 - OoO0O00
                if 0:
                    Ii1I

        else:
            if self.cmd == 'recoveryflash':
                self.line1.setLabel('Preparing for reboot,')
                self.line2.setLabel('please be patient.')
                time.sleep(2)
                IIiIiI = 'recoveryflash /recovery/update.zip'
                try:
                    subprocess.Popen(IIiIiI, shell=True, close_fds=True)
                except:
                    os.system(IIiIiI)
                    if 0:
                        OoO0O00 * I1I1i1 * OoooooooOO + OOo0o0
                    if 0:
                        O0 * o0oOOo0O0Ooo - oO0 % oO0

            else:
                if self.cmd == 'rebootrecovery':
                    self.line1.setLabel('Preparing for reboot,')
                    self.line2.setLabel('please be patient.')
                    time.sleep(2)
                    IIiIiI = 'rebootrecovery'
                    try:
                        subprocess.Popen(IIiIiI, shell=True, close_fds=True)
                    except:
                        os.system(IIiIiI)
                        if 0:
                            oO0 / Oo0Ooo * oO0 + oO0 * i11iIiiIii * I1ii11iIi11i
                        if 0:
                            OOo0o0 / OoOoOO00 - I1I1i1 * OoooooooOO + OoooooooOO.OoOoOO00

                else:
                    if self.cmd == 'emberforcereboot':
                        self.line1.setLabel('Preparing for reboot,')
                        self.line2.setLabel('please be patient.')
                        time.sleep(2)
                        self.killxbmc()
                        time.sleep(5)
                        self.line1.setLabel('Something went wrong executing the reboot command...Please remove power from your device or force close Kodi manually')
                        time.sleep(5)
                        if 0:
                            Ii1I % I1ii11iIi11i
                        if 0:
                            I1I1i1 * I11iii11IIi
                        if 0:
                            OOooOOo
                        if 0:
                            I1IiiI
                    else:
                        time.sleep(1)
                        self.line1.setLabel('Waiting...')
                        time.sleep(2)
                        self.line1.setLabel('Something went wrong executing the command...')
                        time.sleep(2)
                        self.close()
                        if 0:
                            Ii1I / OOo0o0

    def killxbmc(self):
        if 0:
            OOooOOo.O0 % I1IiiI.o0oOOo0O0Ooo + I1I1i1
        if xbmc.getCondVisibility('system.platform.linux'):
            o0o = 'linux'
        else:
            if xbmc.getCondVisibility('system.platform.windows'):
                o0o = 'windows'
            else:
                if xbmc.getCondVisibility('system.platform.osx'):
                    o0o = 'osx'
                else:
                    if xbmc.getCondVisibility('system.platform.atv2'):
                        o0o = 'atv2'
                    else:
                        if xbmc.getCondVisibility('system.platform.ios'):
                            o0o = 'ios'
        print 'Platform: ' + str(o0o)
        if o0o == 'osx':
            print '############   try osx force close  #################'
            try:
                os.system('killall -9 XBMC')
            except:
                pass

            try:
                os.system('killall -9 Kodi')
            except:
                pass

        else:
            if o0o == 'linux':
                print '############   try linux force close  #################'
                if os.path.isfile('/etc/init.d/S95kodi'):
                    try:
                        os.system('pkill -9 kodi && reboot')
                    except:
                        pass

                try:
                    os.system('killall XBMC')
                except:
                    pass

                try:
                    os.system('killall Kodi')
                except:
                    pass

                try:
                    os.system('killall -9 xbmc.bin')
                except:
                    pass

                try:
                    os.system('killall -9 kodi.bin')
                except:
                    pass

            else:
                if o0o == 'windows':
                    print '############   try windows force close  #################'
                    try:
                        os.system('@ECHO off')
                        os.system('tskill XBMC.exe')
                    except:
                        pass

                    try:
                        os.system('@ECHO off')
                        os.system('tskill Kodi.exe')
                    except:
                        pass

                    try:
                        os.system('@ECHO off')
                        os.system('TASKKILL /im Kodi.exe /f')
                    except:
                        pass

                    try:
                        os.system('@ECHO off')
                        os.system('TASKKILL /im XBMC.exe /f')
                    except:
                        pass

                else:
                    print '############   try atv force close  #################'
                    try:
                        os.system('killall AppleTV')
                    except:
                        pass

                print '############   try raspbmc force close  #################'
                try:
                    os.system('sudo initctl stop kodi')
                except:
                    pass

            try:
                os.system('sudo initctl stop xbmc')
            except:
                pass

        if 0:
            OoooooooOO.I11i
        if 0:
            OoOoOO00 - OOooOOo - i1IIi
        if 0:
            O0 * I11i + I1ii11iIi11i.o0oOOo0O0Ooo.o0oOOo0O0Ooo
        if 0:
            I1IiiI


if __name__ == '__main__':
    xbmc.log('SERVICE STARTED - %s' % i1i1II)
    oOoO = OoOooOOOO()
    oOoO.checkForUpdate()
else:
    if __name__ == 'resources.main':
        xbmc.log('SERVICE STARTED - %s' % i1i1II)
        oOoO = OoOooOOOO()
        oOoO.checkForUpdate()