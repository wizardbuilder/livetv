import time

lastActivityTime = 0

while True:
	while True:
		# Add startup delay. This allows kodi start up functions
		currentTime = int(time.time())
		if lastActivityTime == 0:
			lastActivityTime = currentTime
		if (lastActivityTime + 15) < currentTime:
			break
		print("LOOPING - %s " % currentTime)
	print("MAIN")
	time.sleep(2)
	lastActivityTime = currentTime