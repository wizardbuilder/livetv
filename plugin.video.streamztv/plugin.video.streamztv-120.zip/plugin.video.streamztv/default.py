import re
import base64

import urllib, urllib2
import sys, re, os, json, random, string, base64, hashlib, pyaes
import xbmcplugin, xbmcgui, xbmcaddon, xbmc
import net
from urlparse import parse_qsl
import xml.etree.ElementTree as ET
import traceback
import requests

addonID = "plugin.video.streamztv"
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addonID, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addonID, 'icon.png'))
artpath = 'fanart.jpg'
xbmc.translatePath(os.path.join('special://home/addons/' + addonID + '/resources/art/'))

addonPath = xbmcaddon.Addon().getAddonInfo("path")
dialog = xbmcgui.Dialog()
selfAddon = xbmcaddon.Addon(id=addonID)
net = net.Net()

#This list will indicate the channel catagories to check based on their url
checkDirs = {'12':False,   # APK Install Info
              '0':True,   # All Channels inc U.S.A.
              '1':True,   # Entertainment
              '2':False,   # Movies
              '5':True,   # Sports
              '3':False,   # Music
              '4':False,   # News
              '6':False,   # Documentary
              '7':False,   # Kids Corner
              '8':False,   # Food
              '9':True,   # Religious
              '11':True}   # Others



DIALOG_URL = "https://gist.githubusercontent.com/juTTeruk/6159ee8dc47ef1db8dd376eadd68f251/raw/"
ERROR_DIALOG_URL = "https://gist.githubusercontent.com/juTTeruk/9179dd9f658e8d3085ffd2505d7b655a/raw/"
username = '-1'
version = 152

def getVersion():
    # VERSION URL
    req = requests.get("https://gist.githubusercontent.com/juTTeruk/676e6bdab1c2b88d59353ca9f9c92319/raw/")
    if req.status_code != 200:
        return 0
    else:
        return int(req.text)
def isUpdaterInstalled():
    return xbmc.getCondVisibility('System.HasAddon(script.service.pysz)') == 1
    
    
    
def shouldUpdate():
    return getVersion() > version

xml_url = "http://pastebin.com/raw/Xf4CnFzp"

def getXml(url):
    req = requests.get(url)
    return req.content

def parseXml(xml):
    xml = xml.replace("&", "XML_NOT_WORKING")
    root = ET.fromstring(xml)
    a = 0
    for child in root:
        name = child.find("title").text.replace("XML_NOT_WORKING", "&")
        image = child.find("thumbnail").text.replace("XML_NOT_WORKING", "&")
        fanart = child.find("fanart").text.replace("XML_NOT_WORKING", "&")
        url = child.find("link").text.replace("XML_NOT_WORKING", "&")
        type = child.find("type").text.replace("XML_NOT_WORKING", "&")
        if type == "youtube":
            videoId = url.split("?v=")[1]
            addLink(name, '%s' % a, 4, fanart, image, videoId)
        elif type == "othervideo":
            addLink(name, '%s' % a, 7, fanart, image, url.replace("&", "PARSE_NOT_WORKING"), isPlayable=True)
            print url, "debug6969"
        elif type == "androidapp":
            addLink(name, '%s' % a, 6, fanart, image, url)
        elif type == "folder":
            addDir(name, '%s' % a, 5, fanart, image, url)
        elif type == "f4m":
            print "Asdasdasds"
            print url, "asdasd"
            import urllib
            addLink(name, '%s' %a, 8, fanart, image, urllib.quote(url))
        a += 1

def update():
    if shouldUpdate():
        # UPDATE URL
        req = requests.get("http://pastebin.com/raw/gyUd0569")
        if req.status_code != 200:
            print "Something went wrong!"
        else:
            with open(os.path.join(addonPath, "default.py"), "wb") as filewriter:
                filewriter.write(req.text)
# main function

def main():
    addDir('[COLOR lime][B]* Indicates locked catagory, available on the streamZ build only[/B][/COLOR]','12',3,artpath+'All.PNG',fanart)
    addDir('[B] STREAMZ EXTRAS - IPTV TRIAL CHANNELS, full list 400+ available for 5GBP per mth.[/B]','12',3,artpath+'All.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] All Channels inc U.S.A.*','0',1,artpath+'All.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Entertainment*','1',1,artpath+'nt.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Movies','2',1,artpath+'ov.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Sports*','5',1,artpath+'port.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Music','3',1,artpath+'s.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] News','4',1,artpath+'ews.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Documentary','6',1,artpath+'doc.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Kids Corner','7',1,artpath+'ids.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Food','8',1,artpath+'ood.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Religious*','9',1,artpath+'el.PNG',fanart)
    addDir('[COLOR lime]StreamZ[/COLOR] Others*','11',1,artpath+'thers.PNG',fanart)
    xbmc.executebuiltin('Container.SetViewMode(503)')

# Getting popup text
def getDialogText():
    req = requests.get(DIALOG_URL)
    return req.text

def getErrorDialogText():
    req = requests.get(ERROR_DIALOG_URL)
    return req.text

# Getting token

def getToken(url, username):
    s = base64.b64decode("dWt0dm5vdy10b2tlbi0tX3xfLSVzLXVrdHZub3dfdG9rZW5fZ2VuZXJhdGlvbi0lcy1ffF8tMTIzNDU2X3VrdHZub3dfNjU0MzIx")%(url,  username)
    import hashlib
    return hashlib.md5(s).hexdigest()

def getUrl(url, post, headers):
    return requests.post(url, data=post, headers=headers, verify=False).content

def getUKTVUserAgent():
    try:
        username = "-1"#random.choice(usernames)
        post = {'version':'5.7'}
        post = urllib.urlencode(post)
     
        headers = {'User-Agent': 'USER-AGENT-UKTVNOW-APP-V2', 'app-token':getToken(base64.b64decode("aHR0cDovL3VrdHZub3cubmV0L2FwcDIvdjMvZ2V0X3VzZXJfYWdlbnQ="))}
#       headers=[('User-Agent','USER-AGENT-UKTVNOW-APP-V2'),('app-token',getToken(base64.b64decode("aHR0cDovL3VrdHZub3cubmV0L2FwcDIvdjMvZ2V0X3VzZXJfYWdlbnQ="),username))]
        jsondata=getUrl(base64.b64decode("aHR0cDovL3VrdHZub3cubmV0L2FwcDMvdjMvZ2V0X3VzZXJfYWdlbnQ="),post=post,headers=headers)
        jsondata=json.loads(jsondata)    
        import pyaes
        try:
            if 'useragent' in jsondata["msg"]:
                return jsondata["msg"]["useragent"]
        except: 
            pass
        key="wwe324jkl874qq99"
        iv="555eop564dfbaaec"
        decryptor = pyaes.new(key, pyaes.MODE_CBC, IV=iv)
        print 'user agent trying'
        ua= decryptor.decrypt(jsondata["msg"]["54b23f9b3596397b2acf70a81b2da31d"].decode("hex")).split('\0')[0]
        print ua
        return ua
    except: 
        print 'err in user agent'
        traceback.print_exc(file=sys.stdout)
        return 'USER-AGENT-UKTVNOW-APP-V2'
    
# Getting channels

def getChannels():
    token=getToken('http://uktvnow.net/uktvnow8/index.php?case=get_all_channels',username)
    print "ASDASDAADS"
    headers={'User-Agent':'USER-AGENT-UKTVNOW-APP-V2','app-token':token}
    #headers={}
    postdata={'username':username}
    print requests.post('http://uktvnow.net/uktvnow8/index.php?case=get_all_channels',data=postdata,headers=headers, verify=False).content
    channels = requests.post('http://uktvnow.net/uktvnow8/index.php?case=get_all_channels',data=postdata,headers=headers, verify=False).content
    print channels
    channels = channels.replace('\/','/')
    print channels
    match=re.compile('"pk_id":"(.+?)","channel_name":"(.+?)","img":"(.+?)","http_stream":"(.+?)","rtmp_stream":"(.+?)","cat_id":"(.+?)"').findall(channels)
    return match

# Showing the channels

def showChannels(url, check):
    # if check and not isUpdaterInstalled():
    #     path = "plugin://plugin.video.youtube/?action=play_video&videoid=tkYMnU6-bYA"
    #     xbmc.Player().play(path)
    #     xbmc.executebuiltin("XBMC.Container.Update(plugin://plugin.video.streamztv,replace)")
    #     return None
        
    text = getDialogText()
    lines = text.split("\n")
    asd = xbmcgui.Dialog().ok("StreamZTv", *lines)
    
    match = getChannels()
    print match
    for channelid,name,iconimage,stream1,stream2,cat in match:
        thumb='https://app.uktvnow.net/'+iconimage+'|User-Agent=Dalvik/2.1.0 (Linux; U; Android 6.0.1; SM-G935F Build/MMB29K)'
        if url=='0':addLink(name,'url',2,thumb,fanart,channelid)
        if cat==url:addLink(name,'url',2,thumb,fanart,channelid)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)
    xbmc.executebuiltin('Container.SetViewMode(503)')

# Getting the streams

def getStreams(name, iconimage, channelid):
    playlist_token = getToken('http://uktvnow.net/uktvnow8/index.php?case=get_valid_link_revision', username+channelid)
    postdata = {'useragent':getUKTVUserAgent(),'username':username,'channel_id':channelid,'version':'7.5'}
    headers={'User-Agent':'USER-AGENT-UKTVNOW-APP-V2','app-token':playlist_token}
    print "getStreams"
    print (playlist_token, postdata, headers)
    channels = requests.post('http://uktvnow.net/uktvnow8/index.php?case=get_valid_link_revision',data=postdata, headers=headers,verify=False).content
    import json
    channels = json.loads(channels)
    #match=re.compile('"channel_name":"(.+?)","img":".+?","http_stream":"(.+?)","rtmp_stream":"(.+?)"').findall(channels)
    #if len(match) == 0: return
    #match = match[-1]
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    played = False

    try:
        decryptURL(channels["msg"]["channel"][0]["http_stream"])
    except:
        ""
    
    print channels
    xbmc.Player().play(decryptURL(channels["msg"]["channel"][0]["http_stream"]), liz)
    return ok

# Decrypting the URL

def decryptURL(url):
    # magic="1579547dfghuh,difj389rjf83ff90,45h4jggf5f6g,f5fg65jj46,gr04jhsf47890$93".split(',')
    #decryptor = pyaes.new(magic[1], pyaes.MODE_CBC, IV=magic[4])
    decryptor = pyaes.new("555eop564dfbaaec", pyaes.MODE_CBC, IV="wwe324jkl874qq99")
    url= decryptor.decrypt(url.decode("hex")).split('\0')[0]
    return url


# Utilities

# Add link

def addLink(name, url, mode, iconImage, fanart, channelID='', isPlayable=False):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&channelid="+str(channelID)+"&iconimage="+urllib.quote_plus(iconImage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconImage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': channelID } )
    liz.setProperty('fanart_image', fanart)
    liz.addContextMenuItems([], replaceItems=True)
    liz.setProperty("IsPlayable", str(isPlayable).lower())
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

# Add directory

def addDir(name, url, mode, iconImage, fanart, channelID=''):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&channelid="+str(channelID)+"&iconimage="+urllib.quote_plus(iconImage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconImage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': channelID } )
    liz.setProperty('fanart_image', fanart)
    liz.addContextMenuItems([], replaceItems=True)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

# Parse params

def parseParams():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                splitparams={}
                splitparams=pairsofparams[i].split('=')
                if (len(splitparams))==2:
                    param[splitparams[0]]=splitparams[1]
    return param

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if selfAddon.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % selfAddon.getSetting(viewType) )

#params = parseParams()
params = dict(parse_qsl(sys.argv[2][1:]))
params = params if params else {}
url = None
name = None
mode = None
iconImage = None
channelID = None

print str(params) + " asd"
try:
    url = urllib.unquote_plus(params["url"])
except Exception as e:
    print e
    pass

try:
    name = urllib.unquote_plus(params["name"])
except:
    pass

try:
    mode = int(params["mode"])
except Exception as e:
    print e
    pass

try:
    iconImage = urllib.unquote_plus(params["iconimage"])
except:
    pass

try:
    channelID = urllib.unquote_plus(params["channelid"])
except:
    pass
     
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconImage)
print "Full Params: "+str(params)

if mode != None:
    print "ads: " + str(mode)

if mode == None or url == None or len(url) < 1:
    print update()
    main()
elif mode == 1:
    showChannels(url, checkDirs[url])
elif mode == 2:
    getStreams(name, iconImage, channelID)
elif mode == 3:
    xml = getXml(xml_url)
    parseXml(xml)
elif mode == 4:
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid=%s)' % channelID)
elif mode == 5:
    xml = getXml(channelID)
    parseXml(xml)
elif mode == 6:
    xbmc.executebuiltin('StartAndroidActivity("%s")' % channelID)
elif mode == 7:
    print channelID.replace("PARSE_NOT_WORKING", "&"), "aosdadasdasdnjlbnvaiwjdfopajdoi"
    liz = xbmcgui.ListItem(path=channelID.replace("PARSE_NOT_WORKING", "&"))
    liz.setProperty("IsPlayable", 'true')
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
elif mode == 8:
    print "working or not working? "
    import urllib
    print urllib.unquote(channelID).replace("&amp;", "&"), "ASDASDASD"
    xbmc.executebuiltin('PlayMedia(%s)' % urllib.unquote(channelID).replace("&amp;", "&"))

if mode != 7:
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
